import type { Plugin } from 'vite'

export interface VtoAssetsOptions {
  /**
   * URL path the SDK assets are served/copied under.
   * Must match `assetsBaseUrl` passed to `initVto` (default `/vto-assets`).
   */
  base?: string
}

/**
 * Serves the @vto/sdk runtime assets (MediaPipe WASM + model, HDRI,
 * placeholder GLB, face worker) in dev and copies them into the build output.
 */
export declare function vtoAssets(options?: VtoAssetsOptions): Plugin

export default vtoAssets
