/**
 * Vite plugin for @vto/sdk host apps.
 *
 * The SDK needs a handful of runtime files served same-origin by the host:
 * the MediaPipe WASM runtime + face_landmarker model, the HDRI environment
 * map, the placeholder GLB, and the prebuilt face-detection worker. They ship
 * inside the npm package under `assets/`; this plugin
 *
 *   - DEV: serves them at `<base>/…` straight from node_modules
 *   - BUILD: copies them into the output dir at `<base>/…`
 *
 * `base` defaults to `/vto-assets`, matching the SDK's default
 * `assetsBaseUrl`. If you change one, change both.
 */
import { createReadStream, existsSync, readdirSync, statSync } from 'node:fs'
import { copyFile, mkdir } from 'node:fs/promises'
import { dirname, join, resolve, extname, sep } from 'node:path'
import { fileURLToPath } from 'node:url'

const ASSETS_DIR = resolve(dirname(fileURLToPath(import.meta.url)), '../assets')

const MIME = {
  '.js': 'text/javascript',
  '.mjs': 'text/javascript',
  '.wasm': 'application/wasm',
  '.task': 'application/octet-stream',
  '.hdr': 'application/octet-stream',
  '.glb': 'model/gltf-binary',
}

/** @param {{ base?: string }} [options] */
export function vtoAssets(options = {}) {
  const base = (options.base ?? '/vto-assets').replace(/\/$/, '')
  let outDir = 'dist'
  let root = process.cwd()

  return {
    name: 'vto-sdk-assets',

    configResolved(config) {
      outDir = config.build.outDir
      root = config.root
    },

    configureServer(server) {
      server.middlewares.use((req, res, next) => {
        const url = (req.url ?? '').split('?')[0]
        if (!url.startsWith(base + '/')) return next()
        // Resolve inside the assets dir only (no traversal).
        const rel = decodeURIComponent(url.slice(base.length + 1))
        const file = resolve(ASSETS_DIR, rel)
        if (!file.startsWith(ASSETS_DIR + sep) || !existsSync(file)) {
          return next()
        }
        res.setHeader(
          'Content-Type',
          MIME[extname(file)] ?? 'application/octet-stream',
        )
        // The wasm/model/HDR files are immutable per SDK version.
        res.setHeader('Cache-Control', 'public, max-age=3600')
        createReadStream(file).pipe(res)
      })
    },

    async writeBundle() {
      const dest = resolve(root, outDir, '.' + base)
      await copyDir(ASSETS_DIR, dest)
    },
  }
}

async function copyDir(src, dest) {
  await mkdir(dest, { recursive: true })
  for (const entry of readdirSync(src)) {
    const s = join(src, entry)
    const d = join(dest, entry)
    if (statSync(s).isDirectory()) await copyDir(s, d)
    else await copyFile(s, d)
  }
}

export default vtoAssets
