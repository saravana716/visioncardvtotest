# @vto/sdk

Embeddable virtual try-on for glasses. A React + Vite host site passes a
frame's **GLB file** and the SDK renders it on the visitor's face — live
camera, MediaPipe face tracking, three.js rendering, temple occlusion, photo
capture — inside a **modal** on the host's UI. The SDK authenticates with an
**API key validated at most once per day** against your license endpoint.

## Install

```bash
pnpm add @vto/sdk        # react >= 18 and react-dom are peer dependencies
```

## Wire up (3 steps)

**1. Vite plugin** — serves/copies the SDK's runtime assets (MediaPipe WASM +
model, HDRI, face-tracking worker, placeholder GLB) at `/vto-assets`:

```ts
// vite.config.ts
import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'
import { vtoAssets } from '@vto/sdk/vite'

export default defineConfig({
  plugins: [react(), vtoAssets()],
})
```

**2. Initialise once** at app start, and import the stylesheet:

```tsx
import '@vto/sdk/styles.css'
import { initVto } from '@vto/sdk'

initVto({
  apiKey: 'vto_live_…',
  licenseUrl: 'https://api.yourservice.com/vto/validate',
  // assetsBaseUrl: '/vto-assets'   (default; must match the plugin's `base`)
  // theme: 'light' | 'dark'
})
```

**3. Render the modal** wherever you need a "Try on" experience:

```tsx
import { useState } from 'react'
import { VtoModal } from '@vto/sdk'

function ProductCard() {
  const [open, setOpen] = useState(false)
  return (
    <>
      <button onClick={() => setOpen(true)}>Try on</button>
      <VtoModal
        open={open}
        onClose={() => setOpen(false)}
        glbUrl="/models/aviator.glb"
        name="Midnight Aviator"
      />
    </>
  )
}
```

The camera starts only while the modal is open and is fully released (camera
track, WebGL context, MediaPipe landmarker) when it closes.

## `<VtoModal>` props

| Prop      | Type          | Default | Notes |
| --------- | ------------- | ------- | ----- |
| `open`    | `boolean`     | —       | Show/hide. |
| `onClose` | `() => void`  | —       | Fired on Esc, scrim click, or the Close button. |
| `glbUrl`  | `string`      | —       | The frame's GLB (same-origin or CORS-enabled). |
| `name`    | `string`      | `'Frame'` | Modal title + capture filename. |
| `autoFit` | `boolean`     | `true`  | Downloads + analyses the GLB once to derive scale/orientation/nose seating automatically, so any reasonably-authored glasses model fits. Disable only for models authored to the canonical conventions (metres, +Y up, front toward +Z, bridge saddle at the origin). |
| `fit`     | `GlassesFit`  | —       | Manual registration params; overrides `autoFit`. |
| `tint`    | `Tint`        | —       | Optional lens recolouring (see exported `TINTS`). Omit to keep the GLB's authored materials. |

## API-key licensing

`initVto` requires a `licenseUrl`. The SDK POSTs:

```json
{ "apiKey": "vto_live_…", "origin": "https://shop.example" }
```

and expects `200 {"valid": true|false}`. The result is cached in
`localStorage`, so the endpoint is hit **at most once per 24 hours** per
browser. Failure policy:

- endpoint says invalid (or 401/403) → try-on is blocked (fail closed)
- endpoint unreachable, but the key validated within the last 7 days →
  try-on continues (grace) with a console warning
- endpoint unreachable and no prior successful validation → blocked
- `licenseUrl: null` → validation disabled (local development only; warns)

A reference implementation lives in `examples/license-server/server.mjs`
(plain Node, ~60 lines, includes per-origin key allow-listing).

## Serving assets from somewhere else

If you serve the SDK assets from a path/CDN other than `/vto-assets`, set the
same value in both places:

```ts
vtoAssets({ base: '/static/vto' })           // vite.config.ts
initVto({ …, assetsBaseUrl: '/static/vto' }) // app entry
```

Note: the face-tracking worker must be **same-origin** with the page (classic
`new Worker(url)` restriction). If it isn't, the SDK automatically falls back
to main-thread detection — it works, but the render loop shares the thread
with inference.

## What's inside

- **MediaPipe FaceLandmarker** (self-hosted WASM + model, no CDN calls) in a
  Web Worker on Chromium; main-thread on WebKit, where worker WebGL2 is
  unreliable (GPU delegate stays available either way).
- **three.js / @react-three/fiber** scene with the camera frame rendered
  in-scene, so face pixels and glasses always come from the same instant.
- One-Euro pose smoothing, yaw-driven temple reveal (fake head occlusion),
  adaptive temple-arm length, GLB auto-fit analysis for arbitrary models.
- Photo capture (countdown → composited 1280×720 PNG → download/share).
- Graceful states: camera permission/denied/in-use cards, no-face and
  low-light hints, browser-unsupported gate, GLB load-failure placeholder.

## Building this package

```bash
pnpm prepare-assets   # copy MediaPipe wasm/model + HDRI + placeholder into assets/
pnpm build            # assets + worker (IIFE) + library (ES) + .d.ts
```
